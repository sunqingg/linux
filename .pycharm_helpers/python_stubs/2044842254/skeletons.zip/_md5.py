# encoding: utf-8
# module _md5
# from /usr/lib64/python3.6/lib-dynload/_md5.cpython-36m-x86_64-linux-gnu.so
# by generator 1.146
# no doc
# no imports

# functions

def md5(*args, **kwargs): # real signature unknown
    """ Return a new MD5 hash object; optionally initialized with a string. """
    pass

# classes

class MD5Type(object):
    # no doc
    def copy(self, *args, **kwargs): # real signature unknown
        """ Return a copy of the hash object. """
        pass

    def digest(self, *args, **kwargs): # real signature unknown
        """ Return the digest value as a bytes object. """
        pass

    def hexdigest(self, *args, **kwargs): # real signature unknown
        """ Return the digest value as a string of hexadecimal digits. """
        pass

    def update(self, *args, **kwargs): # real signature unknown
        """ Update this hash object's state with the provided string. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    block_size = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    digest_size = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

