# encoding: utf-8
# module _codecs_tw
# from /usr/lib64/python3.6/lib-dynload/_codecs_tw.cpython-36m-x86_64-linux-gnu.so
# by generator 1.146
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__map_big5 = None # (!) real value is ''

__map_cp950ext = None # (!) real value is ''

__spec__ = None # (!) real value is ''

